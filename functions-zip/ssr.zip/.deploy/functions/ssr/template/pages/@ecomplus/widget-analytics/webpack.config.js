module.exports = require('../../webpack.config')
